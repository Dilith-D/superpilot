// Static demo dataset for the SuperPilot CRM prototype.
// Workspace: Zephyr Technologies. Operator: Dilith.

export type DealStage =
  | "Discovery"
  | "Qualified"
  | "Proposal"
  | "Negotiation"
  | "Closed Won"
  | "Closed Lost";

export type DealHealth = "on-track" | "at-risk" | "stalled" | "hot";

export type Deal = {
  id: string;
  company: string;
  logoSeed: string; // for monogram color
  amount: number;
  stage: DealStage;
  health: DealHealth;
  probability: number;
  closeDate: string;
  owner: string;
  primaryContactId: string;
  industry: string;
  lastTouch: string; // relative
  nextStep: string;
};

export type Contact = {
  id: string;
  name: string;
  title: string;
  company: string;
  email: string;
  phone: string;
  avatar?: string;
};

export type IntelKind =
  | "signal"
  | "risk"
  | "next-step"
  | "commitment"
  | "win";

export type DraftPayload =
  | {
      kind: "email";
      to: string;
      subject: string;
      body: string;
    }
  | {
      kind: "meeting";
      to: string;
      title: string;
      proposedTimes: string[];
      body: string;
    }
  | {
      kind: "transcript";
      title: string;
      excerpt: string;
      speaker: string;
    };

export type IntelCard = {
  id: string;
  kind: IntelKind;
  dealId: string;
  headline: string;
  detail: string;
  source: string;
  confidence: number;
  cta: { label: string; verb: "draft" | "schedule" | "review" | "open" };
  timestamp: string;
  draft?: DraftPayload;
};

export const contacts: Contact[] = [
  {
    id: "priya-mehta",
    name: "Priya Mehta",
    title: "VP of Revenue Operations",
    company: "Acme Corp",
    email: "priya.mehta@acmecorp.com",
    phone: "+1 (415) 555-0182",
  },
  {
    id: "marcus-chen",
    name: "Marcus Chen",
    title: "Chief Technology Officer",
    company: "Northwind Labs",
    email: "marcus@northwindlabs.io",
    phone: "+1 (206) 555-0144",
  },
  {
    id: "elena-rossi",
    name: "Elena Rossi",
    title: "Director of Procurement",
    company: "Helios Manufacturing",
    email: "e.rossi@helios-mfg.com",
    phone: "+1 (312) 555-0199",
  },
  {
    id: "samir-okafor",
    name: "Samir Okafor",
    title: "Head of Customer Success",
    company: "Brightline Health",
    email: "samir.o@brightlinehealth.com",
    phone: "+1 (617) 555-0123",
  },
  {
    id: "hannah-vogel",
    name: "Hannah Vogel",
    title: "VP Engineering",
    company: "Kestrel Robotics",
    email: "hannah@kestrelrobotics.ai",
    phone: "+1 (650) 555-0177",
  },
  {
    id: "david-park",
    name: "David Park",
    title: "Chief Financial Officer",
    company: "Lumen Financial",
    email: "d.park@lumenfin.com",
    phone: "+1 (212) 555-0166",
  },
];

export const deals: Deal[] = [
  {
    id: "acme-corp",
    company: "Acme Corp",
    logoSeed: "AC",
    amount: 184_000,
    stage: "Negotiation",
    health: "hot",
    probability: 78,
    closeDate: "Jun 14, 2026",
    owner: "Dilith",
    primaryContactId: "priya-mehta",
    industry: "Logistics SaaS",
    lastTouch: "2h ago",
    nextStep: "Send redlined MSA to Priya",
  },
  {
    id: "northwind-labs",
    company: "Northwind Labs",
    logoSeed: "NL",
    amount: 92_500,
    stage: "Proposal",
    health: "on-track",
    probability: 55,
    closeDate: "Jul 02, 2026",
    owner: "Dilith",
    primaryContactId: "marcus-chen",
    industry: "DevTools",
    lastTouch: "Yesterday",
    nextStep: "Technical deep-dive with platform team",
  },
  {
    id: "helios-manufacturing",
    company: "Helios Manufacturing",
    logoSeed: "HM",
    amount: 312_000,
    stage: "Qualified",
    health: "at-risk",
    probability: 35,
    closeDate: "Aug 21, 2026",
    owner: "Dilith",
    primaryContactId: "elena-rossi",
    industry: "Industrial",
    lastTouch: "5d ago",
    nextStep: "Re-engage Elena — security questionnaire stalled",
  },
  {
    id: "brightline-health",
    company: "Brightline Health",
    logoSeed: "BH",
    amount: 67_800,
    stage: "Discovery",
    health: "on-track",
    probability: 25,
    closeDate: "Sep 30, 2026",
    owner: "Dilith",
    primaryContactId: "samir-okafor",
    industry: "Healthcare",
    lastTouch: "3d ago",
    nextStep: "Discovery call with operations lead",
  },
  {
    id: "kestrel-robotics",
    company: "Kestrel Robotics",
    logoSeed: "KR",
    amount: 145_000,
    stage: "Proposal",
    health: "stalled",
    probability: 40,
    closeDate: "Jun 28, 2026",
    owner: "Dilith",
    primaryContactId: "hannah-vogel",
    industry: "Robotics",
    lastTouch: "9d ago",
    nextStep: "Nudge — Hannah hasn't opened the proposal",
  },
  {
    id: "lumen-financial",
    company: "Lumen Financial",
    logoSeed: "LF",
    amount: 228_000,
    stage: "Negotiation",
    health: "on-track",
    probability: 62,
    closeDate: "Jul 18, 2026",
    owner: "Dilith",
    primaryContactId: "david-park",
    industry: "Fintech",
    lastTouch: "1d ago",
    nextStep: "Procurement review — confirm SOC 2 docs received",
  },
];

export const intelFeed: IntelCard[] = [
  {
    id: "intel-1",
    kind: "commitment",
    dealId: "acme-corp",
    headline: "You committed to send redlined MSA by Thursday",
    detail:
      "On the call with Priya at 2:14pm, you said: \"I'll have legal turn the redlines around by end of day Thursday.\" That's 36 hours away.",
    source: "Call · Tue 2:14pm · 28 min",
    confidence: 96,
    cta: { label: "Draft MSA email", verb: "draft" },
    timestamp: "2h ago",
    draft: {
      kind: "email",
      to: "priya.mehta@acmecorp.com",
      subject: "Acme × Zephyr — redlined MSA attached",
      body: `Hi Priya,

As promised on Tuesday's call, attached are the redlined MSA and the updated DPA. Legal turned them around a day early.

Headline changes from your team's markup:
  • §4.2 Termination for convenience — accepted, 60-day notice as you proposed.
  • §7 Liability cap — moved to 1.5× annual fees (from 1×). Happy to walk through the reasoning.
  • §11 Data residency — added EU-only option as a schedule we can flip on at any time.

You mentioned our two-week onboarding was the deciding factor internally — I've included the implementation timeline as Exhibit C so your steering committee can see it side-by-side with the contract terms.

If everything looks good, we can countersign as soon as you send it back. Let me know if you want a quick 15-min call to walk through anything.

Best,
Dilith`,
    },
  },
  {
    id: "intel-2",
    kind: "risk",
    dealId: "helios-manufacturing",
    headline: "Helios has gone dark — 5 days since last reply",
    detail:
      "Elena's last message asked for SOC 2 Type II and a procurement reference. No outbound since. Procurement cycle averages 18 days; you're at day 14.",
    source: "Email thread · last reply Fri",
    confidence: 88,
    cta: { label: "Draft re-engage", verb: "draft" },
    timestamp: "5d ago",
    draft: {
      kind: "email",
      to: "e.rossi@helios-mfg.com",
      subject: "Following up — SOC 2 + procurement reference",
      body: `Hi Elena,

Wanted to circle back on the two items you asked for last Friday:

  1. SOC 2 Type II report — attached. Covers our most recent audit window (Jan–Dec 2025), no exceptions.
  2. Procurement reference — Mara Lin, Director of Procurement at Northwind Labs. Happy to make a warm intro; she ran a similar evaluation last quarter and is on record as a reference.

I know procurement cycles move on their own clock. If there's anything blocking on your side — security review, legal, budget timing — I'd rather hear it than guess. Even a one-line "we're at X stage" helps me stay out of your way until you need me.

Thanks Elena,
Dilith`,
    },
  },
  {
    id: "intel-3",
    kind: "signal",
    dealId: "lumen-financial",
    headline: "David Park forwarded your proposal internally",
    detail:
      "Tracked link opened 7 times from 3 new IPs at Lumen Financial in the last 24 hours. Two opens from the CFO's office hours.",
    source: "Doc analytics · last 24h",
    confidence: 92,
    cta: { label: "Open deal", verb: "open" },
    timestamp: "4h ago",
  },
  {
    id: "intel-4",
    kind: "next-step",
    dealId: "northwind-labs",
    headline: "Schedule the technical deep-dive Marcus asked for",
    detail:
      "Marcus said his platform team has bandwidth next Tuesday or Wednesday. You have a 90-min open on Wed 10am PT that matches their working hours.",
    source: "Call · Mon 11:02am",
    confidence: 84,
    cta: { label: "Schedule call", verb: "schedule" },
    timestamp: "Yesterday",
    draft: {
      kind: "meeting",
      to: "marcus@northwindlabs.io",
      title: "Northwind × Zephyr — Platform technical deep-dive",
      proposedTimes: [
        "Tue, May 26 · 10:00–11:30am PT",
        "Wed, May 27 · 10:00–11:30am PT (recommended)",
        "Wed, May 27 · 2:00–3:30pm PT",
      ],
      body: `Hi Marcus,

Following up on Monday's call — sending three options for the 90-min platform deep-dive with your team. Wednesday 10am PT is my strong preference; it overlaps cleanly with your working hours.

Agenda I'm proposing:
  • 0–20 min — Architecture walkthrough (ingestion → enrichment → API)
  • 20–60 min — Q&A with your platform team (Raj, Jin, anyone else you want in)
  • 60–90 min — Sandbox tenant, hands-on with their own data

I'll bring our Principal Engineer (Anya Volkov) on for the technical Q&A.

Pick whichever slot works and I'll send the invite.

Dilith`,
    },
  },
  {
    id: "intel-5",
    kind: "risk",
    dealId: "kestrel-robotics",
    headline: "Hannah hasn't opened the proposal in 9 days",
    detail:
      "Proposal sent May 11. Zero opens, zero forwards. Last call she flagged budget freeze risk through end of quarter — likely deprioritized.",
    source: "Doc analytics · 9d",
    confidence: 79,
    cta: { label: "Draft check-in", verb: "draft" },
    timestamp: "9d ago",
    draft: {
      kind: "email",
      to: "hannah@kestrelrobotics.ai",
      subject: "Quick check-in — should we pause?",
      body: `Hi Hannah,

No pressure on a reply — just want to make sure I'm not adding noise to your inbox.

Last we spoke, you mentioned a possible budget freeze through end of quarter. If that landed, totally understand and I'd rather just pause cleanly and pick this back up in July than keep nudging.

If the freeze didn't land and the proposal is just stuck behind other priorities, let me know and I'll send a tightened version that's easier to push through.

Either way — let me know which mode you want me in.

Dilith`,
    },
  },
  {
    id: "intel-6",
    kind: "win",
    dealId: "acme-corp",
    headline: "Priya cited your onboarding speed as the deciding factor",
    detail:
      "Direct quote from the call: \"Your two-week onboarding versus their eight is what tipped this for me internally.\" Worth surfacing in the MSA cover note.",
    source: "Call transcript · Tue 2:14pm",
    confidence: 94,
    cta: { label: "Review transcript", verb: "review" },
    timestamp: "2h ago",
    draft: {
      kind: "transcript",
      title: "Acme Corp — Negotiation call",
      speaker: "Priya Mehta · 14:23",
      excerpt: `…honestly, the procurement team was leaning the other way on price. What I had to walk them through — and what tipped this for me internally — was your two-week onboarding versus their eight.

When I framed it as "six extra weeks of revenue impact for our sales team", the math just stopped being close. We're not optimizing for the cheapest line item, we're optimizing for time-to-value.

So yeah. Get me the redlines and let's move.`,
    },
  },
];

// ---- helpers

export function getDeal(id: string) {
  return deals.find((d) => d.id === id);
}

export function getContact(id: string) {
  return contacts.find((c) => c.id === id);
}

export function getDealsForContact(contactId: string) {
  return deals.filter((d) => d.primaryContactId === contactId);
}

export function getContactBrief(id: string) {
  return contactBriefs[id];
}

// ---- contact brief (Phase 5) ----

export type ContactBrief = {
  contactId: string;
  relationship: string; // 1-2 sentence narrative
  role: "Economic Buyer" | "Champion" | "Technical Evaluator" | "Blocker" | "Influencer";
  sentiment: "warm" | "neutral" | "cold";
  lastInteraction: string; // human label
  knownFor: string[]; // quick facts
  watchOuts: string[]; // risks / sensitivities
  recentMoments: { at: string; what: string }[]; // 3-5 recent interactions
};

export const contactBriefs: Record<string, ContactBrief> = {
  "priya-mehta": {
    contactId: "priya-mehta",
    relationship:
      "Strong, fast-moving. Priya treats you as a peer — she'll be candid about internal politics if you stay specific and don't waste her time.",
    role: "Economic Buyer",
    sentiment: "warm",
    lastInteraction: "Negotiation call · Tue 2:14pm",
    knownFor: [
      "Decides on time-to-value, not lowest price",
      "Background in operations — speaks in workflow terms, not features",
      "Quietly running point on a 3-tool consolidation; you're the first signed",
    ],
    watchOuts: [
      "Procurement (Marcus Lee, not on your calls) is a 1× liability-cap hawk",
      "Out 6/16–6/19 — get signature before that or slip to Q3",
    ],
    recentMoments: [
      { at: "Tue 2:14pm", what: "Verbal commit on call. Quoted: \"two-week onboarding is what tipped this.\"" },
      { at: "May 12", what: "Asked for implementation timeline broken out as a separate exhibit." },
      { at: "May 5", what: "Brought Vikram (CTO) and Renu (impl lead) to the technical walkthrough." },
      { at: "Apr 28", what: "Inbound — referred by Mara Lin at Northwind." },
    ],
  },
  "marcus-chen": {
    contactId: "marcus-chen",
    relationship:
      "Technical buyer with conviction. Marcus likes architecture clarity and is unimpressed by salesy framing — let Anya carry the deep technical moments.",
    role: "Champion",
    sentiment: "warm",
    lastInteraction: "Call · Mon 11:02am",
    knownFor: [
      "Ex-platform lead at Stripe, 9 years; takes architecture personally",
      "Board review on Jun 12 — wants a clear narrative he can repeat",
      "Prefers async written deep-dives over slide decks",
    ],
    watchOuts: [
      "His platform lead Raj has a known Honeycomb preference",
      "Will discount any answer that starts with marketing language",
    ],
    recentMoments: [
      { at: "Mon 11:02am", what: "Requested 90-min platform deep-dive with Raj + Jin." },
      { at: "May 14", what: "Acknowledged proposal in one line: \"auto-scale clause is the right shape.\"" },
      { at: "May 8", what: "Discovery call — established budget envelope and decision criteria." },
    ],
  },
  "elena-rossi": {
    contactId: "elena-rossi",
    relationship:
      "Sympathetic but stalled. Elena wants to move and is being slowed by her own security team; treat her as an ally inside a slow machine, not a blocker.",
    role: "Influencer",
    sentiment: "neutral",
    lastInteraction: "Email · Fri (5 days ago)",
    knownFor: [
      "Director of Procurement — process-driven, allergic to surprises",
      "Burned by a 2024 implementation that ran 11 months long",
      "Will share the real blocker if you give her permission to be honest",
    ],
    watchOuts: [
      "Their CISO (not in thread) reportedly pushed back on a comparable vendor in Q1",
      "SAP rep was on-site at Helios HQ on Tuesday — possible parallel eval",
      "5 days of silence on a 14-day-old procurement thread = momentum is decaying",
    ],
    recentMoments: [
      { at: "Today", what: "No reply, 5 days. SuperPilot flagged re-engage window closing." },
      { at: "Tue", what: "Competitor (SAP Field Service) spotted on-site at Helios HQ." },
      { at: "Fri", what: "Asked for SOC 2 Type II + a procurement reference." },
    ],
  },
  "samir-okafor": {
    contactId: "samir-okafor",
    relationship:
      "Curious, not yet committed. Samir is sponsoring the conversation but Maya (ops lead) is the one whose week has to actually change for this to land.",
    role: "Influencer",
    sentiment: "neutral",
    lastInteraction: "Discovery scheduled · today 10:30am",
    knownFor: [
      "Head of Customer Success — sees the problem from CX, not ops",
      "Has internal political capital but isn't the budget owner",
      "Brought Maya in cold; she'll be evaluating you live today",
    ],
    watchOuts: [
      "No exec sponsor yet besides Samir — healthcare procurement is 9 months without one",
      "Maya is new — if she's lukewarm, Samir alone won't carry this",
    ],
    recentMoments: [
      { at: "Today 10:30am", what: "Discovery with Samir + Maya (ops lead). 30 min." },
      { at: "May 9", what: "Intro thread — Samir framed it as \"too many tools, not enough visibility.\"" },
    ],
  },
  "hannah-vogel": {
    contactId: "hannah-vogel",
    relationship:
      "Quietly stalled. Hannah is conflict-averse — she goes silent instead of saying no. Give her a binary out so she can be honest without losing face.",
    role: "Champion",
    sentiment: "cold",
    lastInteraction: "Proposal sent · May 11 (unopened)",
    knownFor: [
      "VP Engineering — owns the tooling budget for the platform group",
      "Flagged a possible Q2 budget freeze on last call",
      "Prefers tight, phased proposals over big-bang rollouts",
    ],
    watchOuts: [
      "9 days, zero opens, zero forwards on the proposal — the deal is in trouble",
      "Don't re-send the same proposal — she'll read that as pressure",
    ],
    recentMoments: [
      { at: "Today", what: "SuperPilot escalated: proposal unopened, recommend a binary re-engage." },
      { at: "May 11", what: "Proposal sent — $145K with phased rollout." },
      { at: "May 2", what: "Hinted at budget freeze risk on call: \"Q2 might lock down.\"" },
    ],
  },
  "david-park": {
    contactId: "david-park",
    relationship:
      "Strong forward motion. David is CFO and is socializing the proposal internally; protect that momentum by giving him the clean procurement path he needs.",
    role: "Economic Buyer",
    sentiment: "warm",
    lastInteraction: "Proposal forwarded · 4h ago",
    knownFor: [
      "CFO — values predictability and clean line items over discounts",
      "Forwarded your proposal to 3 new internal addresses in 24h",
      "Decision style: socialize first, decide fast, then push procurement to move",
    ],
    watchOuts: [
      "Workday account team has incumbency on the rest of Lumen's finance stack",
      "If his CISO hasn't seen SOC 2 yet, security review adds 2 weeks",
    ],
    recentMoments: [
      { at: "4h ago", what: "Proposal forwarded internally · 7 opens from 3 new IPs in 24h." },
      { at: "Yesterday", what: "Proposal v2 sent — $228K ARR with multi-year discount." },
      { at: "May 15", what: "Asked for a one-page summary he could share with the CEO." },
    ],
  },
};


export function formatCurrency(amount: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(amount);
}

export const pipelineTotal = deals
  .filter((d) => d.stage !== "Closed Lost" && d.stage !== "Closed Won")
  .reduce((sum, d) => sum + d.amount, 0);

export const weightedTotal = deals
  .filter((d) => d.stage !== "Closed Lost" && d.stage !== "Closed Won")
  .reduce((sum, d) => sum + d.amount * (d.probability / 100), 0);

// ---- deal record (Phase 4) ----

export type TimelineEvent = {
  id: string;
  kind: "call" | "email" | "meeting" | "note" | "doc" | "stage" | "signal";
  title: string;
  detail: string;
  actor: string;
  at: string; // human label
  highlight?: boolean;
};

export type PreCallBrief = {
  callIn: string; // "Today 3:30pm"
  goal: string;
  talkingPoints: string[];
  risks: string[];
  opener: string;
};

export type DealRecord = {
  dealId: string;
  brief?: PreCallBrief;
  summary: string; // 1-2 sentence narrative
  competitors: string[];
  champions: string[];
  blockers: string[];
  timeline: TimelineEvent[];
  contactIds: string[]; // includes primary + others
};

export const dealRecords: Record<string, DealRecord> = {
  "acme-corp": {
    dealId: "acme-corp",
    summary:
      "Acme is replacing a 4-year-old logistics tool that can't keep up with their new fulfillment network. Priya is the economic buyer and explicit champion; legal is the last gate.",
    competitors: ["RouteWise", "ShipLogic Pro"],
    champions: ["Priya Mehta — VP RevOps"],
    blockers: ["MSA redlines (in flight, 36h)", "Procurement counter-sign"],
    contactIds: ["priya-mehta"],
    brief: {
      callIn: "Thu 3:30pm · 30 min",
      goal: "Walk Priya through MSA redlines, confirm Jun 14 close, lock implementation kickoff for Jun 17.",
      talkingPoints: [
        "Open with her own quote — \"two-week onboarding vs eight is what tipped this internally\" — reinforces the why.",
        "§7 liability cap moved to 1.5× annual fees; explain the reasoning (we settle a single-incident scenario, not a series).",
        "Offer EU data residency as a flippable schedule, not a renegotiation — removes a future surprise.",
        "Confirm Jun 17 kickoff window with her implementation lead, Renu.",
      ],
      risks: [
        "Procurement (Marcus, not on call) historically pushes for 1× cap. If Priya flags this post-call, escalate to your VP.",
        "Acme's fiscal close is Jun 30 — if signature slips past Jun 20, she may push to Q3.",
      ],
      opener:
        "Hey Priya — legal turned the redlines around a day early. I'd love to walk you through the three substantive changes, then talk implementation timing. Sound good?",
    },
    timeline: [
      {
        id: "t-1",
        kind: "signal",
        title: "MSA opened by Acme legal · 3 viewers",
        detail:
          "Tracked link opened in 45 minutes, then re-opened by two new viewers (likely outside counsel). Strong signal redlines are actively in review.",
        actor: "SuperPilot",
        at: "1h ago",
        highlight: true,
      },
      {
        id: "t-2",
        kind: "email",
        title: "MSA + DPA sent to Priya",
        detail:
          "Redlined MSA, updated DPA, implementation timeline (Exhibit C). Used Priya's onboarding quote in the cover note.",
        actor: "Dilith",
        at: "2h ago",
      },
      {
        id: "t-3",
        kind: "call",
        title: "Negotiation call · 28 min",
        detail:
          "Priya confirmed verbal commit. Three open redline items resolved live. SuperPilot captured 7 action items.",
        actor: "Dilith ↔ Priya Mehta",
        at: "Tue 2:14pm",
        highlight: true,
      },
      {
        id: "t-4",
        kind: "stage",
        title: "Stage advanced — Proposal → Negotiation",
        detail: "Auto-advanced after Priya's verbal commit was confirmed.",
        actor: "SuperPilot",
        at: "Tue 2:42pm",
      },
      {
        id: "t-5",
        kind: "doc",
        title: "Proposal v3 delivered",
        detail: "Pricing held at $184K ARR. Two-week onboarding broken out as a separate line.",
        actor: "Dilith",
        at: "May 12",
      },
      {
        id: "t-6",
        kind: "meeting",
        title: "Discovery + technical walkthrough",
        detail: "Priya, Renu (implementation), and their CTO Vikram. 60 min.",
        actor: "Dilith + Anya Volkov",
        at: "May 5",
      },
      {
        id: "t-7",
        kind: "note",
        title: "Deal opened",
        detail: "Inbound from Priya — referred by Mara Lin at Northwind Labs.",
        actor: "Dilith",
        at: "Apr 28",
      },
    ],
  },
  "northwind-labs": {
    dealId: "northwind-labs",
    summary:
      "Northwind is evaluating us as their primary observability platform. Marcus (CTO) is the technical champion; his platform team is the gate.",
    competitors: ["Datadog", "Honeycomb"],
    champions: ["Marcus Chen — CTO"],
    blockers: ["Platform team technical deep-dive"],
    contactIds: ["marcus-chen"],
    brief: {
      callIn: "Wed 10:00am · 90 min",
      goal: "Run the platform deep-dive, win technical conviction from Raj + Jin, and leave with a sandbox tenant provisioned on their data.",
      talkingPoints: [
        "Open with the architecture diagram — ingestion → enrichment → API. Stay above the line; let Anya handle the depths.",
        "Surface the auto-scale clause Marcus liked in the proposal — it's the wedge against Datadog's per-host pricing.",
        "Offer to ingest 24h of their staging telemetry live during the session — converts skeptics faster than slides.",
        "End on next-step: 2-week sandbox eval, weekly checkpoint, decision by Jun 18.",
      ],
      risks: [
        "Raj has a known Honeycomb preference — expect a tracing fidelity question; defer to Anya, do not improvise.",
        "Marcus mentioned a board review Jun 12. If the eval slips past Jun 10, we lose the window for him to bring it up.",
      ],
      opener:
        "Marcus — Anya's joining for the technical Q&A. I'll keep the first 20 minutes tight on architecture, then we hand the room over to your platform team. Sound right?",
    },
    timeline: [
      {
        id: "n-1",
        kind: "call",
        title: "Marcus requested platform deep-dive",
        detail: "Asked for a 90-min session with his platform team. Bandwidth Tue/Wed next week.",
        actor: "Dilith ↔ Marcus Chen",
        at: "Mon 11:02am",
        highlight: true,
      },
      {
        id: "n-2",
        kind: "doc",
        title: "Proposal sent",
        detail: "$92.5K starter tier with auto-scale clause.",
        actor: "Dilith",
        at: "May 14",
      },
      {
        id: "n-3",
        kind: "meeting",
        title: "Discovery call",
        detail: "30 min. Established budget, decision criteria, timeline.",
        actor: "Dilith",
        at: "May 8",
      },
    ],
  },
  "helios-manufacturing": {
    dealId: "helios-manufacturing",
    summary:
      "Helios is in procurement limbo — security questionnaire blocked, no replies in 5 days. Elena is sympathetic but procurement is slow, and a competitor was spotted on-site this week.",
    competitors: ["SAP Field Service"],
    champions: ["Elena Rossi — Director of Procurement"],
    blockers: ["SOC 2 doc + procurement reference (in flight)", "Internal security review", "Possible parallel SAP evaluation"],
    contactIds: ["elena-rossi"],
    brief: {
      callIn: "Re-engage today · async first",
      goal: "Break the 5-day silence with concrete deliverables (SOC 2 + reference) and force a one-line status read from Elena before the SAP rep deepens.",
      talkingPoints: [
        "Lead with what she asked for, not what you want — SOC 2 Type II attached, Mara Lin offered as warm reference.",
        "Give Elena permission to say \"we're slow\" — name the procurement cycle (avg 18d, you're at day 14) so she can be honest about where they actually are.",
        "Soft-anchor a follow-up — \"happy to wait 5 days, then I'll send one final nudge before stepping back\" — protects the relationship if it slips.",
        "If she replies: confirm the security reviewer name + push for a 20-min security Q&A next week.",
      ],
      risks: [
        "At-risk: 5 days of silence on a 14-day-old procurement thread is the classic stall pattern — momentum is decaying daily.",
        "SAP Field Service rep was on-site at Helios HQ on Tuesday (LinkedIn post). Possible parallel evaluation you weren't told about.",
        "Elena is sympathetic but not the decision-maker on security — if their CISO has pushed back, she may be sitting on bad news.",
        "Budget review window closes Jun 30. Slip past that and this likely moves to Q4, not Q3.",
      ],
      opener:
        "Hi Elena — no pressure on a reply, just sending the SOC 2 and the reference I promised. One line on where you actually are would help me stay out of your way.",
    },
    timeline: [
      {
        id: "h-1",
        kind: "signal",
        title: "No reply · 5 days",
        detail: "Procurement cycle averages 18 days; you're at day 14. Re-engage window closing.",
        actor: "SuperPilot",
        at: "Today",
        highlight: true,
      },
      {
        id: "h-2",
        kind: "signal",
        title: "SAP rep on-site at Helios HQ",
        detail: "Competitor account exec posted from Helios on Tuesday. Possible parallel evaluation.",
        actor: "SuperPilot",
        at: "Tue",
        highlight: true,
      },
      {
        id: "h-3",
        kind: "email",
        title: "Elena requested SOC 2 + reference",
        detail: "Last outbound. Awaiting your re-engage with documentation.",
        actor: "Elena Rossi",
        at: "Fri",
      },
    ],
  },
  "brightline-health": {
    dealId: "brightline-health",
    summary: "Early-stage discovery. Samir is exploring, not yet committed.",
    competitors: [],
    champions: ["Samir Okafor — Head of CS"],
    blockers: ["Discovery with operations lead (today 10:30am)"],
    contactIds: ["samir-okafor"],
    brief: {
      callIn: "Today 10:30am · 30 min",
      goal: "Qualify Brightline — confirm pain, budget signal, and decision process. Decide today whether to invest more cycles or politely park.",
      talkingPoints: [
        "Open with Samir's framing from the intro — \"too many tools, not enough visibility\" — and ask him to expand for Maya (ops lead).",
        "Probe the operations workflow: how many handoffs per patient, where the slips happen. Real numbers beat hypotheticals.",
        "Float pricing range early (\"deals like this typically land $60–80K\") — saves a third call if budget isn't there.",
        "Close with a clear yes/no next step: 1) live demo with their data next week, or 2) park until Q3.",
      ],
      risks: [
        "Healthcare procurement is long — if there's no exec sponsor besides Samir, this is a 9-month cycle minimum.",
        "Maya is new — wasn't in the intro thread. If she's lukewarm, Samir alone won't carry this.",
      ],
      opener:
        "Thanks for the time — Samir, since Maya is new to this, mind giving her the 60-second version of why we're talking? Then I'd love to hear what her week actually looks like.",
    },
    timeline: [
      {
        id: "b-1",
        kind: "meeting",
        title: "Discovery scheduled — today 10:30am",
        detail: "30 min with Samir and operations lead.",
        actor: "Dilith",
        at: "Today",
        highlight: true,
      },
    ],
  },
  "kestrel-robotics": {
    dealId: "kestrel-robotics",
    summary:
      "Stalled. Hannah hasn't opened the proposal in 9 days. Budget freeze signal from last call.",
    competitors: [],
    champions: ["Hannah Vogel — VP Engineering"],
    blockers: ["Budget freeze confirmation"],
    contactIds: ["hannah-vogel"],
    brief: {
      callIn: "No call scheduled · re-engage async",
      goal: "Force a clean signal — alive or paused — without burning the relationship. Either re-open the deal or close it cleanly to your forecast.",
      talkingPoints: [
        "Lead with a real out: \"happy to pause cleanly until July\" — gives Hannah permission to be honest about the freeze.",
        "If the freeze landed: offer to send a tightened, phased proposal she can pre-position internally for the Q3 thaw.",
        "If it didn't: ask one question only — what would unblock a 20-min review this week?",
        "Do not re-send the unopened proposal. Send a one-paragraph email with a single ask.",
      ],
      risks: [
        "9 days, zero opens, zero forwards on a $145K proposal = the deal is in trouble. Don't pretend otherwise.",
        "Hannah is conflict-averse — she may go silent rather than say no. A binary ask forces a reply.",
      ],
      opener:
        "Hi Hannah — one question, no pressure: did the budget freeze land, or is this just stuck behind other priorities? Either answer is useful.",
    },
    timeline: [
      {
        id: "k-1",
        kind: "signal",
        title: "Proposal unopened · 9 days",
        detail: "Zero opens, zero forwards since May 11. Last call flagged budget freeze risk.",
        actor: "SuperPilot",
        at: "Today",
        highlight: true,
      },
      {
        id: "k-2",
        kind: "doc",
        title: "Proposal sent",
        detail: "$145K with phased rollout.",
        actor: "Dilith",
        at: "May 11",
      },
    ],
  },
  "lumen-financial": {
    dealId: "lumen-financial",
    summary:
      "Strong forward motion. David (CFO) forwarded the proposal internally — 7 opens from 3 new IPs in 24h.",
    competitors: ["Workday Financial"],
    champions: ["David Park — CFO"],
    blockers: ["Procurement (in flight)", "SOC 2 doc confirmation"],
    contactIds: ["david-park"],
    brief: {
      callIn: "Fri 11:00am · 30 min",
      goal: "Convert the forwarded-proposal signal into a procurement timeline. Get the SOC 2 confirmation, name the procurement contact, lock a target signature week.",
      talkingPoints: [
        "Open by naming the signal — \"saw the proposal got some traction internally\" — without naming the analytics. Let David control the narrative.",
        "Confirm SOC 2 report was received and routed to their security team; offer to walk through it directly if helpful.",
        "Ask for the procurement contact by name — \"who do we copy on the redlines?\" — and push for signature week of Jun 24.",
        "Tee up multi-year discount only if he asks about pricing flexibility; otherwise hold the line at the $228K number.",
      ],
      risks: [
        "Workday's account team has incumbency on the rest of Lumen's finance stack — they may underbid late if procurement opens it up.",
        "If David's CISO hasn't seen SOC 2 yet, security review could add 2 weeks. Confirm on call.",
      ],
      opener:
        "David — looked like the proposal got some traction internally this week. Wanted to make sure SOC 2 is in the right hands and figure out what a clean path to signature looks like from here.",
    },
    timeline: [
      {
        id: "l-1",
        kind: "signal",
        title: "Proposal forwarded internally · 7 opens, 3 new IPs",
        detail: "Two opens during CFO's office hours. Strong buy signal.",
        actor: "SuperPilot",
        at: "4h ago",
        highlight: true,
      },
      {
        id: "l-2",
        kind: "doc",
        title: "Proposal v2 sent",
        detail: "$228K ARR with multi-year discount.",
        actor: "Dilith",
        at: "Yesterday",
      },
    ],
  },
};

export function getDealRecord(id: string): DealRecord | undefined {
  return dealRecords[id];
}

// ---- tasks (Phase 6) ----

export type TaskKind = "commitment" | "follow-up" | "risk" | "next-step" | "note";

export type TaskPriority = "critical" | "high" | "medium" | "low";

export type TaskStatus = "open" | "done" | "snoozed";

export type Task = {
  id: string;
  dealId: string;
  headline: string;
  detail: string;
  kind: TaskKind;
  priority: TaskPriority;
  status: TaskStatus;
  dueGroup: "today" | "this-week" | "later";
  dealLabel: string; // e.g. "Acme Corp"
  contactLabel?: string;
};

export const tasks: Task[] = [
  {
    id: "task-1",
    dealId: "acme-corp",
    headline: "Send redlined MSA to Priya",
    detail:
      "Committed on Tue call: \"I'll have legal turn the redlines around by end of day Thursday.\" That's 36 hours away.",
    kind: "commitment",
    priority: "critical",
    status: "open",
    dueGroup: "today",
    dealLabel: "Acme Corp",
    contactLabel: "Priya Mehta",
  },
  {
    id: "task-2",
    dealId: "helios-manufacturing",
    headline: "Re-engage Elena with SOC 2 + reference",
    detail:
      "5 days of silence on a 14-day procurement thread. SAP rep was on-site at Helios on Tuesday. Re-engage window closing.",
    kind: "follow-up",
    priority: "high",
    status: "open",
    dueGroup: "today",
    dealLabel: "Helios Manufacturing",
    contactLabel: "Elena Rossi",
  },
  {
    id: "task-3",
    dealId: "kestrel-robotics",
    headline: "Binary check-in with Hannah",
    detail:
      "Proposal unopened for 9 days. Budget freeze risk flagged. Need a clean alive/paused signal.",
    kind: "risk",
    priority: "high",
    status: "open",
    dueGroup: "this-week",
    dealLabel: "Kestrel Robotics",
    contactLabel: "Hannah Vogel",
  },
  {
    id: "task-4",
    dealId: "northwind-labs",
    headline: "Schedule platform technical deep-dive",
    detail:
      "Marcus has bandwidth Tue/Wed next week. 90-min session with Raj + Jin. Need to send invite with three options.",
    kind: "next-step",
    priority: "high",
    status: "open",
    dueGroup: "this-week",
    dealLabel: "Northwind Labs",
    contactLabel: "Marcus Chen",
  },
  {
    id: "task-5",
    dealId: "lumen-financial",
    headline: "Confirm SOC 2 reached Lumen security team",
    detail:
      "Proposal is getting internal traction. Need to make sure David's CISO has seen the SOC 2 report.",
    kind: "follow-up",
    priority: "medium",
    status: "open",
    dueGroup: "this-week",
    dealLabel: "Lumen Financial",
    contactLabel: "David Park",
  },
  {
    id: "task-6",
    dealId: "brightline-health",
    headline: "Discovery call with Samir + operations lead",
    detail:
      "Today 10:30am. Qualify Brightline — confirm pain, budget signal, and decision process. Decide whether to invest more cycles or park.",
    kind: "next-step",
    priority: "medium",
    status: "done",
    dueGroup: "today",
    dealLabel: "Brightline Health",
    contactLabel: "Samir Okafor",
  },
  {
    id: "task-7",
    dealId: "acme-corp",
    headline: "Walk Priya through MSA redlines",
    detail:
      "Call Thu 3:30pm. Walk through §7 liability cap, EU data residency schedule, confirm Jun 17 kickoff.",
    kind: "next-step",
    priority: "critical",
    status: "open",
    dueGroup: "today",
    dealLabel: "Acme Corp",
    contactLabel: "Priya Mehta",
  },
  {
    id: "task-8",
    dealId: "acme-corp",
    headline: "Review negotiation call transcript",
    detail:
      "Priya cited two-week onboarding as the deciding factor. Worth surfacing in the MSA cover note.",
    kind: "note",
    priority: "medium",
    status: "open",
    dueGroup: "this-week",
    dealLabel: "Acme Corp",
    contactLabel: "Priya Mehta",
  },
  {
    id: "task-9",
    dealId: "lumen-financial",
    headline: "Name procurement contact at Lumen",
    detail:
      "Need to get the redline counterparty name from David. Push for signature week of Jun 24.",
    kind: "follow-up",
    priority: "medium",
    status: "open",
    dueGroup: "later",
    dealLabel: "Lumen Financial",
    contactLabel: "David Park",
  },
  {
    id: "task-10",
    dealId: "northwind-labs",
    headline: "Prepare sandbox tenant for platform demo",
    detail:
      "For the deep-dive session — have staging data ready so Raj and Jin can see real ingestion in action.",
    kind: "note",
    priority: "medium",
    status: "open",
    dueGroup: "this-week",
    dealLabel: "Northwind Labs",
    contactLabel: "Marcus Chen",
  },
];

export const openTaskCount = tasks.filter((t) => t.status === "open").length;
export const todayTaskCount = tasks.filter((t) => t.status === "open" && t.dueGroup === "today").length;

// ---- inbox / comms (Phase 7) ----

export type CommsChannel = "email" | "call" | "sms" | "slack" | "meeting";
export type CommsDirection = "inbound" | "outbound";

export type CommsMessage = {
  id: string;
  channel: CommsChannel;
  direction: CommsDirection;
  from: string; // display name
  fromHandle?: string; // email / phone / @handle
  to?: string;
  timestamp: string; // relative
  subject?: string;
  body: string;
  attachments?: { name: string; size: string }[];
  durationSec?: number; // for calls
};

export type CommsThread = {
  id: string;
  dealId: string;
  contactId: string;
  subject: string;
  channel: CommsChannel; // primary channel of the thread
  preview: string;
  participants: string[]; // names
  lastActivity: string; // relative
  lastActivityRank: number; // for sort (lower = newer)
  unreadCount: number;
  hasAttachment?: boolean;
  starred?: boolean;
  pinned?: boolean;
  superpilotSummary?: string; // AI summary
  superpilotNextStep?: string;
  messages: CommsMessage[];
};

export const commsThreads: CommsThread[] = [
  {
    id: "thread-acme-msa",
    dealId: "acme-corp",
    contactId: "priya-mehta",
    subject: "Re: MSA redlines — §7 liability cap & EU data residency",
    channel: "email",
    preview:
      "Thanks, looks workable. Legal will turn redlines around by EOD Thursday — let's lock Tuesday for the walk-through.",
    participants: ["Priya Mehta", "Dilith", "Jordan Reyes (Legal)"],
    lastActivity: "2h ago",
    lastActivityRank: 1,
    unreadCount: 1,
    hasAttachment: true,
    pinned: true,
    superpilotSummary:
      "Priya is committed to EOD Thursday for legal redlines. Two open items: §7 liability cap (she'll push for 2x ACV) and EU data residency schedule. Kickoff target Jun 17.",
    superpilotNextStep:
      "Send a tight 3-line confirmation tonight: thank her, confirm Thu 3:30pm walk-through, attach SOC 2 + EU DPA addendum.",
    messages: [
      {
        id: "m1",
        channel: "email",
        direction: "inbound",
        from: "Priya Mehta",
        fromHandle: "priya.mehta@acmecorp.com",
        to: "dilith@zephyr.com",
        timestamp: "2h ago",
        subject: "Re: MSA redlines — §7 liability cap & EU data residency",
        body: "Hi Dilith,\n\nThanks for the quick turn on the data residency schedule — looks workable. I just got off with Jordan (our GC) and we'll have the redlines back to you by EOD Thursday.\n\nTwo things we still want to land:\n1. §7 — we'd like the liability cap at 2x annual fees, not 1x.\n2. EU residency — confirm Frankfurt + Dublin failover, not just Frankfurt.\n\nLet's lock Tuesday 3:30pm for the walk-through. Jordan and I will both be on.\n\nThanks,\nPriya",
        attachments: [{ name: "Acme_MSA_v3_redlined.pdf", size: "412 KB" }],
      },
      {
        id: "m0",
        channel: "email",
        direction: "outbound",
        from: "Dilith",
        fromHandle: "dilith@zephyr.com",
        to: "priya.mehta@acmecorp.com",
        timestamp: "Yesterday",
        subject: "MSA redlines — §7 liability cap & EU data residency",
        body: "Hi Priya,\n\nAttached is v3 of the MSA with the changes we discussed:\n• §4.2 — payment terms moved to Net-45\n• §11 — added the EU data residency schedule (Frankfurt primary, Dublin failover)\n• §16 — cleaned up the termination-for-convenience language\n\nLet me know if §7 (liability cap) is workable as-is or if you'd like to talk it through. Happy to grab 20 minutes this week.\n\nDilith",
        attachments: [{ name: "Acme_MSA_v3.pdf", size: "398 KB" }],
      },
    ],
  },
  {
    id: "thread-acme-call",
    dealId: "acme-corp",
    contactId: "priya-mehta",
    subject: "Call transcript — Negotiation review (32 min)",
    channel: "call",
    preview:
      "Priya: \"Honestly the two-week onboarding is what got this past our CFO. If you can keep that in writing, we're good.\"",
    participants: ["Priya Mehta", "Dilith"],
    lastActivity: "Yesterday",
    lastActivityRank: 2,
    unreadCount: 0,
    pinned: true,
    superpilotSummary:
      "32-min call. Strong buying signals: Priya cited 2-week onboarding as the CFO-deciding factor. One concern: integration with their NetSuite instance — flagged for technical follow-up.",
    superpilotNextStep:
      "Surface the 2-week onboarding commitment explicitly in the MSA cover note. Loop Raj on NetSuite integration question by Friday.",
    messages: [
      {
        id: "c1",
        channel: "call",
        direction: "inbound",
        from: "Priya Mehta",
        fromHandle: "+1 (415) 555-0182",
        timestamp: "Yesterday · 11:04am",
        body: "Transcript excerpt (12:18 → 14:02):\n\nPRIYA: Honestly the two-week onboarding is what got this past our CFO. If you can keep that in writing, we're good.\n\nDILITH: We can put that in the SOW as a milestone. If we slip, you get a credit.\n\nPRIYA: Perfect. The other thing — and I should've flagged this on the last call — we're on NetSuite, not Oracle. Does your connector cover that out of the box?\n\nDILITH: Yes, NetSuite is native. I'll have Raj send you the integration brief by Friday so your team can sanity-check it.\n\nPRIYA: Great. Send the redlines and let's get this done.",
        durationSec: 32 * 60,
      },
    ],
  },
  {
    id: "thread-helios-silence",
    dealId: "helios-manufacturing",
    contactId: "elena-rossi",
    subject: "Re: SOC 2 report + reference customer",
    channel: "email",
    preview:
      "Elena hasn't replied since the SAP rep was on-site Tue. SuperPilot flagged: 5 days silent on a 14-day procurement thread.",
    participants: ["Elena Rossi", "Dilith"],
    lastActivity: "5d ago",
    lastActivityRank: 3,
    unreadCount: 0,
    hasAttachment: true,
    superpilotSummary:
      "Procurement thread went cold after SAP did an on-site at Helios. Re-engage window is narrow — every day of silence raises the probability they default to incumbent.",
    superpilotNextStep:
      "Send a value-led re-engage: SOC 2 attached + a one-line reference quote from a peer manufacturer. Keep it under 5 lines, no \"just checking in.\"",
    messages: [
      {
        id: "h2",
        channel: "email",
        direction: "outbound",
        from: "Dilith",
        fromHandle: "dilith@zephyr.com",
        to: "e.rossi@helios-mfg.com",
        timestamp: "5d ago",
        subject: "SOC 2 report + reference customer",
        body: "Hi Elena,\n\nAs requested — attached is our latest SOC 2 Type II report. I also lined up a reference call with the VP Ops at Sentinel Forge (similar discrete-manufacturing setup, 18 months live with us). Let me know which window works:\n\n• Tue 10:00 CT\n• Wed 2:30 CT\n• Thu 11:00 CT\n\nDilith",
        attachments: [{ name: "Zephyr_SOC2_TypeII_2026.pdf", size: "1.2 MB" }],
      },
      {
        id: "h1",
        channel: "email",
        direction: "inbound",
        from: "Elena Rossi",
        fromHandle: "e.rossi@helios-mfg.com",
        to: "dilith@zephyr.com",
        timestamp: "9d ago",
        subject: "Re: Procurement next steps",
        body: "Dilith — can you send your SOC 2 and a reference from another manufacturer? Procurement wants both before we slot you onto the shortlist review.\n\nElena",
      },
    ],
  },
  {
    id: "thread-northwind-demo",
    dealId: "northwind-labs",
    contactId: "marcus-chen",
    subject: "Platform deep-dive — scheduling 90 min with Raj + Jin",
    channel: "email",
    preview:
      "Marcus has bandwidth Tue/Wed next week. Wants a working session, not a pitch — staging data on real ingestion.",
    participants: ["Marcus Chen", "Dilith"],
    lastActivity: "Yesterday",
    lastActivityRank: 4,
    unreadCount: 1,
    superpilotSummary:
      "Marcus is a technical buyer treating this as an architectural review, not a demo. He's explicitly asking for staging data and live ingestion — the deal turns on how Raj and Jin handle the depth questions.",
    superpilotNextStep:
      "Send a calendar invite with 3 options (Tue 10am, Tue 2pm, Wed 11am all PT). Prep a sandbox tenant with Northwind-shape data so it's real, not generic.",
    messages: [
      {
        id: "n1",
        channel: "email",
        direction: "inbound",
        from: "Marcus Chen",
        fromHandle: "marcus@northwindlabs.io",
        to: "dilith@zephyr.com",
        timestamp: "Yesterday",
        subject: "Re: Next step after the proposal",
        body: "Dilith,\n\nProposal looks solid. Before we go further I want our platform leads (Raj, Jin) to do a 90-min working session with your team. Not a demo — I want them poking at the ingestion pipeline with realistic data and seeing how it actually behaves at our scale.\n\nWe have bandwidth Tue/Wed next week. Send three options and I'll lock one.\n\nMarcus",
      },
    ],
  },
  {
    id: "thread-kestrel-quiet",
    dealId: "kestrel-robotics",
    contactId: "hannah-vogel",
    subject: "Proposal — still on the table?",
    channel: "email",
    preview:
      "Proposal opened 0 times in 9 days. SuperPilot suggests a binary alive/paused message — no pressure, just clarity.",
    participants: ["Hannah Vogel", "Dilith"],
    lastActivity: "9d ago",
    lastActivityRank: 5,
    unreadCount: 0,
    superpilotSummary:
      "Proposal sent 9 days ago, zero opens. Budget freeze was rumored on the last call. Without a binary signal, this slot is dead weight in the forecast.",
    superpilotNextStep:
      "Send a 2-sentence binary check-in: \"Are we still on, paused, or off?\" Make it easy to say paused — that's worth more than a maybe.",
    messages: [
      {
        id: "k1",
        channel: "email",
        direction: "outbound",
        from: "Dilith",
        fromHandle: "dilith@zephyr.com",
        to: "hannah@kestrelrobotics.ai",
        timestamp: "9d ago",
        subject: "Proposal v1 — for review",
        body: "Hi Hannah,\n\nAttached the proposal we walked through on Friday. Pricing reflects the Q3 start we discussed, with the engineering services line broken out so you can flex it.\n\nHappy to do a working session if helpful — otherwise I'll check in next week.\n\nDilith",
        attachments: [{ name: "Kestrel_Proposal_v1.pdf", size: "624 KB" }],
      },
    ],
  },
  {
    id: "thread-lumen-internal",
    dealId: "lumen-financial",
    contactId: "david-park",
    subject: "Internal: SOC 2 routed to CISO — confirming receipt",
    channel: "slack",
    preview:
      "David: \"Got it, forwarded to Anjali. She'll want a 30-min walkthrough before signing off.\"",
    participants: ["David Park", "Dilith"],
    lastActivity: "3d ago",
    lastActivityRank: 6,
    unreadCount: 0,
    superpilotSummary:
      "Lumen is moving internally. SOC 2 reached CISO Anjali. She wants a 30-min security walkthrough — that's a buying step, not a stall.",
    superpilotNextStep:
      "Propose Wed/Thu 30-min slots with Anjali. Bring Maya (Security Eng) so it's peer-to-peer, not sales-to-security.",
    messages: [
      {
        id: "l1",
        channel: "slack",
        direction: "inbound",
        from: "David Park",
        fromHandle: "@david.park",
        timestamp: "3d ago",
        body: "Got it, forwarded to Anjali. She'll want a 30-min walkthrough before signing off. Can you propose times next week?",
      },
    ],
  },
  {
    id: "thread-brightline-discovery",
    dealId: "brightline-health",
    contactId: "samir-okafor",
    subject: "SMS — confirming 10:30 discovery call today",
    channel: "sms",
    preview: "Samir: \"Confirmed — see you at 10:30. Bringing Ops lead Tasha too.\"",
    participants: ["Samir Okafor", "Dilith"],
    lastActivity: "5h ago",
    lastActivityRank: 7,
    unreadCount: 0,
    superpilotSummary:
      "Samir bringing Ops lead Tasha is a positive signal — multi-threading on his side without being asked.",
    superpilotNextStep:
      "Tailor the discovery for two audiences: outcomes for Samir (CS metrics), workflow specifics for Tasha (day-to-day).",
    messages: [
      {
        id: "b1",
        channel: "sms",
        direction: "inbound",
        from: "Samir Okafor",
        fromHandle: "+1 (617) 555-0123",
        timestamp: "5h ago",
        body: "Confirmed — see you at 10:30. Bringing Ops lead Tasha too.",
      },
      {
        id: "b0",
        channel: "sms",
        direction: "outbound",
        from: "Dilith",
        fromHandle: "+1 (415) 555-0001",
        timestamp: "Yesterday",
        body: "Hi Samir — confirming our discovery call tomorrow Wed 10:30am CT. Sending an agenda over email shortly.",
      },
    ],
  },
];

export const inboxUnreadCount = commsThreads.reduce((n, t) => n + t.unreadCount, 0);

export function getThreadsForDeal(dealId: string): CommsThread[] {
  return commsThreads.filter((t) => t.dealId === dealId);
}

export function getThreadsForContact(contactId: string): CommsThread[] {
  return commsThreads.filter((t) => t.contactId === contactId);
}
